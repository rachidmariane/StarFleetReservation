package main.java.fr.Starfleet.modele.personne;

public abstract class Personne {
    private String nom;
    private String prenom ;
    private String identifiant ;
    //Constructeur
    public Personne(String nom, String prenom, int identifiant2) {
        this.nom = nom;
        this.prenom = prenom;
        this.identifiant = identifiant2;
    }
    //Getters
    public String getNom() {
        return nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public String getIdentifiant() {
        return identifiant;
    }
    //Setters
    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public void setIdentifiant(String identifiant) {
        this.identifiant = identifiant;
    }
    //Méthode abstraire 
    public abstract String getDescription();
}


