package main.java.fr.Starfleet.modele.personne;
public abstract class Officier extends main.java.fr.Starfleet.modele.personne.Personne {
    private int rang;
    private String sprecialite;
    public Officier(String nom, String prenom, String identifiant, int rang, String specialite) {
            super(nom, prenom, identifiant);    
            this.rang = rang;
            this.sprecialite = specialite;
    }
    public int getRang() {
        return rang;
    }
    public String getSprecialite() {
        return sprecialite;
    }
    public void setRang(int rang) {
        this.rang = rang;
    }
    public void setSprecialite(String sprecialite) {
        this.sprecialite = sprecialite;
    }

    
    
}